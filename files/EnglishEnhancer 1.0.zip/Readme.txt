Welcome to Enhancer!

This program helps you to improve your writing and reading skills by enlarging your vocabulary through synonyms. 

Press [F6] to start analysis the input: e.g.
This is a good day! Is it supercalifragilisticexpialidocious? 

You will see words underscored which suggest synonyms exist, and words in the notebook bold. 

Feel free to use my database, and substitute the "Resource.ini" file, and of course enjoy many of its functions: notebook (with a familiarity counter), gender tracker, a built-in web browser, a timer (bottom right), and auto-saving. 


<<<IMPORTANT NOTICE>>>
This program is solely for individual use, and any attempt to commercialize the software is not allowed without the author's permission. Any adaptation and repackaging of the program is prohibited without further authorization. You may distribute the program if and only if it follows the original will of the author. For contact info, check the "About Us..." menu. 
